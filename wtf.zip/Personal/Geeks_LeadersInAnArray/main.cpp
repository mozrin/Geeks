#include <bits/stdc++.h> 

using namespace std; 

int main() 
{ 
    int T, N;
    
    cin >> T;
    
    while (T--)
    {
        
        cin >> N;
        
        int A[N];
        
        for (int i=0; i<N; i++) { cin >> A[i]; }
        
        for (int i=0; i<N-1; i++)
        {
            if (A[i] > A[i+1]); // Do The Thing }
        }
        
    }
    
    return 0; 
}
