#include <bits/stdc++.h>

// Each exercise's main() function is contained in this section.

int Exercise_0904()
{
    
    std::cout << "main() Lab Assignment for Chapter 9 (648-650) Section 9.4\n\n";
    
    return 0;
}