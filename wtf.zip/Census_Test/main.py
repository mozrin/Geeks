# Standard Libraries

import requests
import json

# My Libraries

import census_eq2

# Code Below

census_eq2.GetDatatypes()