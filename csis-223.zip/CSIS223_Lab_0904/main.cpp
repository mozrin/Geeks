// CODE FROZEN: 20200613
//
// Use the FORK THIS button to grab a version of this program that you can make changes to!

#include <bits/stdc++.h>

// This code will only run in a perfect world. Only rudimentary error handling is included. In order
// to make this more robust, try/catch{} and advanced error handling should be included.

// Helper Functions

using namespace std; // Always a bad idea to use this in production code. The better option is to learn about namespaces.

string ltrim(string str, string chars = "\t\n\v\f\r ")
{
    str.erase(0, str.find_first_not_of(chars));
    
    return str;
}
 
string rtrim(string str, string chars = "\t\n\v\f\r ")
{
    str.erase(str.find_last_not_of(chars) + 1);
    
    return str;
}
 
string trim(string str, string chars = "\t\n\v\f\r ")
{
    return ltrim(rtrim(str, chars), chars);
}

#define PE_WI(p,w) setprecision(p) << setw(w) << fixed
#define AL_PE_WI(a,p,w) (a?left:right) << setprecision(p) << setw(w) << fixed

// Change this if you want to change the number of records in the file. Alternatively,
// we could write a routine that would count the number of rows in the file and 
// then allocate the array accordingly.
// 
// Of course in the real world, we would be using SQL or some other relational database
// instead of a text file.

const int    NUMBER_ITEMS        = 8;
const string BREAKFAST_MENU_FILE = "BreakfastMenu.txt";

struct menuItemType
{
	string menuItem;
	double menuPrice;
};

// Assignment Function Prototypes

int GetBreakfastMenuItems(menuItemType (&items)[NUMBER_ITEMS]);

void PrintMenu(menuItemType[]);


// Main routine

int main()
{
    int rc = 0;
    
    menuItemType menuItems[NUMBER_ITEMS];
    
    rc = GetBreakfastMenuItems(menuItems);
    
    PrintMenu(menuItems);
    
    return rc;
}

void PrintMenu(menuItemType items[])
{
    cout << "Header" << endl << "-------------------------" << endl;
    
    int counter = 0;
    
    do
    {
        string menuItemName = items[counter].menuItem;
        double menuItemPrice = items[counter].menuPrice;
        
        cout << AL_PE_WI(0,0,2) << counter << " - ";
        cout << AL_PE_WI(1,0,20) << menuItemName;
        cout << AL_PE_WI(0,0,10) << menuItemPrice;
        
        counter++;
        
        if (counter == NUMBER_ITEMS) { break; }
        
    } while (true);
    
    
    
    return;
}

int GetBreakfastMenuItems(menuItemType (&items)[NUMBER_ITEMS])
{
    int rc = 0, counter = 0;
    
    double tempPrice;
    string tempItem, tempFileRow;
    
    ifstream menuFile(BREAKFAST_MENU_FILE);
    
    cout << endl;
    
    do
    {
        if (menuFile.eof()) { break; }
        
        getline(menuFile, tempFileRow);
        
        // replace(tempFileRow.begin(), tempFileRow.end(), '\r', ' ');
        
        cout << "Counter |" << counter << "| Temp Row: |" << trim(tempFileRow) << "|" << endl;
        
        items[counter].menuItem = tempFileRow;
        
        getline(menuFile, tempFileRow);
        
        // replace(tempFileRow.begin(), tempFileRow.end(), '\r', ' ');
        
        cout << "Counter |" << counter << "| Temp Row: |" << trim(tempFileRow) << "|" << endl;
        
        items[counter].menuPrice = stod(tempFileRow);
        
        counter++;
        
    } while (true);
      
      // cout << counter;
      
      menuFile.close();
      
      //for (int i=0; i<NUMBER_ITEMS; i++) { cout << items[i].menuItem << "..." << items[i].menuPrice << endl; }
      //
      exit(0);
	
    if (menuFile.fail())
    {
        cout << "Error opening file (" + BREAKFAST_MENU_FILE + ")\n\n";
        
		rc = 1;
    }
    
    else
    {
        int counter = 0;
    
        do
        {
            if (menuFile.eof()) { break; } // No more records. Exit the loop.
            
            // Read Data from the File
            
            getline(menuFile, items[counter].menuItem);
            menuFile >> items[counter].menuPrice;

            counter++;
            
        } while (counter < NUMBER_ITEMS);
            
        menuFile.close();
    }
    
    return rc;
}