#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

struct dateType
{
    int month;
    int day;
    int year;
};

const int MALE_ELIGIBILITY_AGE = 65;
const int FEMALE_ELIGIBILITY_AGE = 62;

int ageInYears(dateType birthDate, dateType today);
int getNumberRange(int lowNumber, int highNumber);

bool isLeapYear(int year);
bool isEligible(int currAge, char sex);

dateType getDate(string prompt = "Enter a valid date:  ");

int main()
{
    dateType currDate;
    dateType dob;
    
    char gender;
    
    int age;
    
    currDate = getDate("Enter current date ... ");
    
    do
    {
        cout << "________________________________________________\n\n";
        
        do
        {
            cout << "Gender M/F - Q quits:  ";
            cin >> gender;
    
            gender = toupper(gender);
            
            if (gender == 'Q' || gender == 'M' || gender == 'F')
            {
                break;
            }
            
        } while (true);
        
        if (gender == 'Q') { break; }
        
        dob = getDate("Enter date of birth ... ");
        
        age = ageInYears(dob, currDate);
        
        cout << "Gender:  " << gender << "    Age:  " << age << "     ";
        
        cout << (isEligible(age, gender) ? "E" : "Not e") << "ligible\n\n";
        
    } while (true);
    
    return 0;
}

int getNumberRange(string prompt, int lowNumber, int highNumber)
{
    int inputNumber;
    
    do
    {
        cout << prompt;
        cin >> inputNumber;
        
        if (inputNumber < lowNumber || inputNumber > highNumber )
        {
            cout << "**** INVALID Number: Must be >= " << lowNumber;
            cout << " and <= " << highNumber << "!\n";
        }
        else
        { 
            cout << endl;
            break;
        }
        
    } while (true);
}

dateType getDate(string prompt)
{
    int y;
    int maxDays = 31;
    
    dateType inputDate;

    cout << prompt;
    cout << endl;

    inputDate.month = getNumberRange("      Enter month [1-12]:  ", 1, 12);
    inputDate.year  = getNumberRange("  Enter year [1900-2020]:  ", 1900, 2020);
    
    switch(inputDate.month)
    {
        case  9 :
        case  4 :
        case  6 :
        case 11 : maxDays = 30; break;
        
        case  1 :
        case  3 :
        case  5 :
        case  7 :
        case  8 :
        case 10 :
        case 12 : maxDays = 31; break;
        
        default : maxDays = 28 + (isLeapYear(inputDate.year) ? 1 : 0); break;
    }
    
    inputDate.day   = getNumberRange("        Enter day [1-varies]:  ", 1, maxDays);
    
    return inputDate;
}

bool isLeapYear(int year)
{
    bool returnCode = false;
    
    returnCode = (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0));
    
    return returnCode;
}

int ageInYears(dateType birthDate, dateType today)
{
    int by, bm, bd, cy, cm, cd, a;
    
    by = birthDate.year;
    bm = birthDate.month;
    bd = birthDate.day;
    
    cy = today.year;
    cm = today.month;
    cd = today.day;
    
    
    
    return (cy - by) + (cm < bm ? -1 : 0) + ((cm == bm) && (cd < bd) ? -1 : 0);
}

bool isEligible(int currAge, char sex)
{
    return ((sex = 'M') && (currAge >= MALE_ELIGIBILITY_AGE)) ||
           ((sex = 'F') && (currAge >= FEMALE_ELIGIBILITY_AGE));
}
