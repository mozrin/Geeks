#include <bits/stdc++.h>

using namespace std;

// Helper Functions

string str_toupper(string s)
{
    transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return toupper(c); });
    
    return s;
}

// Roman Class

class Roman
{
    public:
    
    Roman(string r);
    
    int GetDecimal();
    
    void SetInput(string r);
    
    int output;
    
    string input;
};

// This is a little sloppy, but will work as long as the setting of the input variable is the only thing that happens
// when I SetInput(). Otherwise, the instantiation should call the SetInput().

Roman::Roman(string r) { input = r; }

void Roman::SetInput(string r)
{
    input = r;
    
    return;
}

int Roman::GetDecimal()
{
    // This is the most efficient way I could think of to do this ...
    
    map<char, int> romanMap = {{'I', 1}, {'V', 5}, {'X', 10}, {'L', 50}, {'C', 100}, {'D', 500}, {'M', 1000}};
    
    int total = 0;
    
    for (int i = 0; i < input.length(); i++)
    {
        if (romanMap[input[i+1]] <= romanMap[input[i]])
        {
            total += romanMap[input[i]];
        }
        else
        {
            total -= romanMap[input[i]];  
        }
    }
    
    return total;
}

int main()
{
    int rc = 0;
    
    cout << "Enter a Roman Numeral sequence and press <Enter>, Q to quit.\n\n";
    
    do
    {
        string romanNumerals;
        
        cin >> romanNumerals;
        
        romanNumerals = str_toupper(romanNumerals);
        
        if (romanNumerals == "Q") { break; }
        
        Roman r(romanNumerals);
        
        int output = r.GetDecimal();
        
        cout << romanNumerals << " = ";
        
        if (output == 0)
        {
            // There are other errors that can occur and other roman numberals not covered.
            // This tool could be significantly augmented.
            
            cout << "ERROR";
        }
        
        else
        {
            cout << output;
        }
        
        cout << endl;
        
    } while (true);
    
    return rc;
}
