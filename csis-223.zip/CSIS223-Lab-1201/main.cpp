// CSIS 223 CHAP 12, PROBLEM 1, PAGE 890
// CODE FROZEN: 20200722
//
// Use the FORK THIS button to grab a version of this program that you can make changes to!

#include <bits/stdc++.h>

// This code will only run in a perfect world. Only rudimentary error handling is included. In order
// to make this more robust, try/catch{} and advanced error handling should be included.

using namespace std; // Always a bad idea to use this in production code. The better option is to learn about namespaces.

// Assignment Classes and Functions

string str_toupper(string s)
{
    // A string is an array of characters. This is a function I include 
    // in every piece of code I have ever written. It takes a passed
    // char[] or string and uses the transform() function to convert
    // it to upper, lower, proper, replace, et al.
    
    // I was not the first to create it ... and will undoubtedly not
    // be the last to type some for of this function.
    
    transform( s.begin(),
               s.end(),
               s.begin(),
               
               // Runs function with char as parameter from the string
               // for each increment of the transform from s.begin to 
               //s.end against toupper().
               
               [](unsigned char c) { return toupper(c); }
             );
             
    return s;
}

string toUpperCase(string inputString);

int main()
{
    string inputString;
    
    cout << "Enter a mixed case string: ";
    getline(cin, inputString);
    
    cout << endl;
    cout << "You entered   [" << inputString << "]" << endl;
    cout << "str_toupper() [" << str_toupper(inputString) << "]";
    cout << endl;
    
    return 0;
}

