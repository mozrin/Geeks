// CSIS 223 LAB 0902
// CODE FROZEN: 20200613
//
// Use the FORK THIS button to grab a version of this program that you can make changes to!

#include <bits/stdc++.h>

// This code will only run in a perfect world. Only rudimentary error handling is included. In order
// to make this more robust, try/catch{} and advanced error handling should be included.

using namespace std; // Always a bad idea to use this in production code. The better option is to learn about namespaces.

#define PE_WI(p,w) setprecision(p) << setw(w) << fixed
#define AL_PE_WI(a,p,w) (a?left:right) << setprecision(p) << setw(w) << fixed

// Change this if you want to change the number of records in the file. Alternatively,
// we could write a routine that would count the number of rows in the file and 
// then allocate the array accordingly.
// 
// Of course in the real world, we would be using SQL or some other relational database
// instead of a text file.

const int NUMBER_OF_SCORES = 20; 

struct studentRecord
{
	string firstName;
	string lastName;
    int testScore;
    char letterGrade;
};

// Assignment Function Prototypes

int FindHighestTestScore(studentRecord record[]);
int ReadStudentDataIntoStructure(studentRecord (&record)[NUMBER_OF_SCORES]);

void PrintHighestScoreAndStudents(studentRecord record);

studentRecord AssignGradeToStudent(studentRecord record);

// Main routine

int main()
{
    int rc = 0, highScore = 0;

    studentRecord studentRecords[NUMBER_OF_SCORES];
    
    // Print Header
    
    cout << AL_PE_WI(1,0,25) << "Student Name" << AL_PE_WI(1,0,6) << "Score" << AL_PE_WI(1,0,6) << "Grade" << endl;
    cout << AL_PE_WI(1,0,25) << "------------------------" << AL_PE_WI(1,0,6) << "-----" << AL_PE_WI(1,0,6) << "-----" << endl;
    
    // Read Data Into Structure
    
    rc = ReadStudentDataIntoStructure(studentRecords);
    
    if (!rc)
    {
        highScore = FindHighestTestScore(studentRecords);
        
        cout << endl << "The highest score for this test is " << highScore << " by:" << endl << endl;

        for (int i=0; i<NUMBER_OF_SCORES ; i++)
        {
            if (studentRecords[i].testScore == highScore)
            {
                PrintHighestScoreAndStudents(studentRecords[i]);
            }
        }
    }
    
    else
    {
        cout << "Error processing student records." << endl << endl;
    }
    
    return rc;
}

// Assignment Functions

void PrintHighestScoreAndStudents(studentRecord record)
{
    string fullName = record.lastName + ", " + record.firstName;
                    
    cout << "   " << fullName << endl;
}

// Assignment Functions 

studentRecord AssignGradeToStudent(studentRecord record)
{
    char grade;
    
    record.letterGrade = "FFFFFFDCBAA"[(record.testScore / 10)];
    
    return record;
}

int FindHighestTestScore(studentRecord record[])
{
    int rc = 0;
    
    // I wrote this function as instructed, but the code is easier/faster to understand, read, and maintain when
    // it is in the function where the data is read. Otherwise you are looping through the struct multiple times.
    
    for (int i=0; i<NUMBER_OF_SCORES; i++)
    {
        rc = (record[i].testScore > rc) ? record[i].testScore : rc;
    }
    
    return rc;
}

int ReadStudentDataIntoStructure(studentRecord (&record)[NUMBER_OF_SCORES])
{
    int rc = 0, counter = 0, testScore;
    
    char letterGrade;
    
    string fullName;
    
    ifstream studentScores("studentScores.txt");
	
    if (studentScores.fail())
    {
        cout << "Error opening student records file (studentScores.txt)\n\n";
        
		rc = 1;
    }
    
    else
    {
    
        do
        {
            if (studentScores.eof()) { break; } // No more records. Exit the loop.
            
            // Read Data from the File
            
            studentScores >> record[counter].firstName
                          >> record[counter].lastName
                          >> record[counter].testScore;
            
            // This next statement is by instruction and not the most efficient way to handle
            // the calculation and assignment of the grade to the record. Specifically, a single
            // statement would have sufficed. See below:
            //
            // studentRecords[counter].letterGrade = "FFFFFFDCBAA"[(studentRecords[counter].testScore / 10)];
            
            record[counter] = AssignGradeToStudent(record[counter]);
                          
            // Write/Format the Output
            
            fullName    = record[counter].lastName + ", " + record[counter].firstName;
            testScore   = record[counter].testScore;
            letterGrade = record[counter].letterGrade;
            
            cout << AL_PE_WI(1,0,27)
                 << fullName
                 << AL_PE_WI(1,0,6)
                 << testScore
                 << AL_PE_WI(1,0,3)
                 << letterGrade
                 << endl;
                 
            // The above statement should really be in a try/catch structure. Making a lot of assumptions here.

            counter++;
            
        } while (true);
            
        studentScores.close();
    }
    
    return rc;
}