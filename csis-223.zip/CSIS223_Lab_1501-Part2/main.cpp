// CSIS 223 CHAP 15, PROBLEM 1, PAGE 1064
// CODE FROZEN: 20200722
//
// Use the FORK THIS button to grab a version of this program that you can make changes to!

#include <bits/stdc++.h>

// This code will only run in a perfect world. Only rudimentary error handling is included. In order
// to make this more robust, try/catch{} and advanced error handling should be included.

using namespace std; // Always a bad idea to use this in production code. The better option is to learn about namespaces.

// Assignment Function

void OutputStars(int);
void OutputStarsDown(int);
void OutputStarsUp(int, int);

int main()
{
    int inputStars = 0;
    
    cout << "Enter the number of stars for the pattern: ";
    cin >> inputStars;
    cout << "\n\n";
    
    OutputStars(inputStars);
    
    return 0;
}

void OutputStars(int stars)
{
    OutputStarsDown(stars);
    OutputStarsUp(1, stars);
    
    return;
}

void OutputStarsDown(int stars)
{
    if (stars > 0)
    {
        for (int i = 0; i < stars; i++)
        {
            cout << "*";
        }
        
        cout << endl;
        
        OutputStarsDown(--stars);
    }
    
    return;
}

void OutputStarsUp(int stars, int maxStars)
{
    if (stars <= maxStars)
    {
        for (int i = 0; i < stars; i++)
        {
            cout << "*";
        }
        
        cout << endl;
        
        OutputStarsUp(++stars, maxStars);
    }
    
    return;
}