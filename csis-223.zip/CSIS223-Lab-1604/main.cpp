// CSIS 223 CHAP 16, PROBLEM 4, PAGE 1111
// CODE FROZEN: 20200722
//
// Use the FORK THIS button to grab a version of this program that you can make changes to!

#include <bits/stdc++.h>

// This code will only run in a perfect world. Only rudimentary error handling is included. In order
// to make this more robust, try/catch{} and advanced error handling should be included.

using namespace std; // Always a bad idea to use this in production code. The better option is to learn about namespaces.

// Assignment Classes and Functions

void removeAtIndex(vector<int> &integers, int size, int removeAt)
{
    int rc = -1;
    
    if (integers.size() == 0)
    {
        cout << " FAILURE: Containers is empty!" << endl;
        
        rc = -2;
    }
    
    else if (integers.size() < removeAt)
    {
        cout << " FAILURE: Index value to remove is larger than the container!" << endl;
        rc = -1;
    }
    
    else
    {
        integers.erase(integers.begin() + removeAt);
        
        cout << " COMPLETE: Removed occurance at " << removeAt << endl;
        
        integers.resize(size - 1);
        
        rc = 0;
    }
    
    return;
}

int main()
{
    int sizeOfContainer;
    
    vector<int> integers1 = { 1,2,3,4,5,6,7,8,9,4,5,6,7,8,3,2,1,5,6,7,8,3,1,0,1,0,
                              2,8,7,4,3,2,9,0,0,9,1,2,6,5,1,9,3,0,1,2,3,8,6,5,1,1 };
    vector<int> integers2 = { };
    
    cout << "Chapter 16, Problem 4, Page 1111-1112\n";
    cout << "-------------------------------------\n";
    cout << "Create a function that removes value at index number.\n\n";
    
    // Remove a valid number ...

    cout << " removeAtIndex(integers1, size, 2)\n";
    sizeOfContainer = integers1.size();
    cout << " size = " << integers1.size() << "\n";
    removeAtIndex(integers1, sizeOfContainer, 2);
    cout << " size = " << integers1.size() << "\n\n";

    // Remove an invalid number ...
    
    cout << " removeAtIndex(integers1, size, 121212)\n";
    sizeOfContainer = integers1.size();
    cout << " size = " << integers1.size() << "\n";
    removeAtIndex(integers1, sizeOfContainer, 121212);
    cout << " size = " << integers1.size() << "\n\n";
    
    // Remove from vactor size 0
        
    cout << " removeAtIndex(integers2, size, 2)\n";
    sizeOfContainer = integers2.size();
    cout << " size = " << integers2.size() << "\n";
    removeAtIndex(integers2, sizeOfContainer, 2);
    cout << " size = " << integers2.size() << "\n";

    return 0;
}


