// CSIS 223 CHAP 16, PROBLEM 3, PAGE 1111
// CODE FROZEN: 20200722
//
// Use the FORK THIS button to grab a version of this program that you can make changes to!

#include <bits/stdc++.h>

// This code will only run in a perfect world. Only rudimentary error handling is included. In order
// to make this more robust, try/catch{} and advanced error handling should be included.

using namespace std; // Always a bad idea to use this in production code. The better option is to learn about namespaces.

// Assignment Classes and Functions

void removeFirstOccurance(vector<int> &integers, int size, int removeMe)
{
    int rc = -1;
    
    if (integers.size() == 0)
    {
        cout << " FAILURE: Containers is empty!" << endl;
        
        rc = -2;
    }
    
    else
    {
        for (int i = 0; i < size; i++)
        {
            if (integers[i] == removeMe)
            {
                integers.erase(integers.begin() + i);
                integers.resize(size - 1);
                
                rc = 0;
                
                cout << " COMPLETE: Removed the first occurance of " << removeMe << endl;
                
                break;
            }
        }
    }
    
    if (rc == -1) { cout << " FAILURE: Could not find any occurance of " << removeMe << endl; }
    
    return;
}

int main()
{
    int sizeOfContainer;
    
    vector<int> integers1 = { 1,2,3,4,5,6,7,8,9,4,5,6,7,8,3,2,1,5,6,7,8,3,1,0,1,0,
                              2,8,7,4,3,2,9,0,0,9,1,2,6,5,1,9,3,0,1,2,3,8,6,5,1,2 };
    vector<int> integers2 = { };
    
    cout << "Chapter 16, Problem 3, Page 1111\n";
    cout << "--------------------------------\n";
    cout << "Create a function that removes the first occurance of a value.\n\n";
    
    // Remove a valid number ...

    cout << " removeFirstOccurance(integers1, size, 2)\n";
    sizeOfContainer = integers1.size();
    cout << " size = " << integers1.size() << "\n";
    removeFirstOccurance(integers1, sizeOfContainer, 2);
    cout << " size = " << integers1.size() << "\n\n";

    // Remove an invalid number ...
    
    cout << " removeFirstOccurance(integers1, size, 12)\n";
    sizeOfContainer = integers1.size();
    cout << " size = " << integers1.size() << "\n";
    removeFirstOccurance(integers1, sizeOfContainer, 12);
    cout << " size = " << integers1.size() << "\n\n";
    
    // Remove from vactor size 0
        
    cout << " removeFirstOccurance(integers2, size, 2)\n";
    sizeOfContainer = integers2.size();
    cout << " size = " << integers2.size() << "\n";
    removeFirstOccurance(integers2, sizeOfContainer, 2);
    cout << " size = " << integers2.size() << "\n";

    return 0;
}
