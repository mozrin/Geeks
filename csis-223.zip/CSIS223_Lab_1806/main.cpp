// CSIS 223 CHAP 18, PROBLEM 6, PAGE 1305
// CODE FROZEN: 20200722
//
// Use the FORK THIS button to grab a version of this program that you can make changes to!

#include <bits/stdc++.h>

// This code will only run in a perfect world. Only rudimentary error handling is included. In order
// to make this more robust, try/catch{} and advanced error handling should be included.

using namespace std; // Always a bad idea to use this in production code. The better option is to learn about namespaces.

// Assignment Classes and Functions

int main()
{
	int positiveInteger, bottomLimit, countFactors = 0;
	
	stack<int> listOfFactors;
	{
		cout << "Enter a positive integer: ";
		cin >> positiveInteger;
		cout << endl;
		
		cout << "Prime Factors / Descending Order of " << positiveInteger;
		cout << endl << endl; 
		
		bottomLimit = positiveInteger / 2;

		for (int i = 2; i<= bottomLimit; i++)
		{
			if (positiveInteger % i == 0)
			{
			    countFactors++;
				listOfFactors.push(i);
			}
		}
		
		cout << "There " << (countFactors < 2?"is ":"are ") << countFactors;
		cout << " prime factor" << (countFactors < 2?"":"s") << " for the above number.";
		cout << endl << endl;
		cout << "Specifically (in descending order): ";

		while (!listOfFactors.empty())
		{
			cout << listOfFactors.top() << "  ";
			listOfFactors.pop();
		}
		
		cout << endl;
	}
	
	return 0;
}