#include <bits/stdc++.h>

using namespace std;

const double MINIMUM_RANDOM = 10;
const double MAXIMUM_RANDOM = 100;
const int TOTAL_GENERATED = 25;

double GetRandomDouble(double, double);

int main()
{
    srand(static_cast<unsigned int>(time(nullptr))); 
  
    for (int count = 1; count <= TOTAL_GENERATED; ++count)
    {
        cout << setw(4) << right << count << ": ";
        cout << fixed << setprecision(7) << right;
        cout << GetRandomDouble(MINIMUM_RANDOM, MAXIMUM_RANDOM) << "\n";
    }
     
  return 0;
}

double GetRandomDouble(double minimum, double maximum)
{
    double f = (double)rand() / RAND_MAX;
    
    return minimum + f * (maximum - minimum);
}