// CSIS 223 CHAP 11, PROBLEM 8, PAGE 814
// CODE FROZEN: 20200722
//
// Use the FORK THIS button to grab a version of this program that you can make changes to!

#include <bits/stdc++.h>

// This code will only run in a perfect world. Only rudimentary error handling is included. In order
// to make this more robust, try/catch{} and advanced error handling should be included.

using namespace std; // Always a bad idea to use this in production code. The better option is to learn about namespaces.

// Assignment Classes and Functions

const int DATE_FORMAT_MDY = 1;
const int DATE_FORMAT_DMY = 2;
const int DATE_FORMAT_YMD = 3;

class dateType
{
    public:
    
    dateType(int month, int day, int year);

    void setDate(int month, int day, int year);
    
    int getDay() const;
    
    int getMonth() const;
    
    int getYear() const;
    
    void printDate(int format = DATE_FORMAT_MDY) const;
    
    protected:
    
    int dDay;
    int dMonth;
    int dYear;
};

dateType::dateType(int month, int day, int year)
{
    dMonth = month;
    dDay = day;
    dYear = year;
}

void dateType::setDate(int month, int day, int year)
{
    dMonth = month;
    dDay = day;
    dYear = year;
}

int dateType::getMonth() const { return dMonth; }

int dateType::getDay() const { return dDay; }

int dateType::getYear() const { return dYear; }

void dateType::printDate(int format) const
{
    switch(format)
    {
        case DATE_FORMAT_YMD:
        
        cout << dYear << '-' << dMonth << '-' << dDay;
        
        break;
        
        case DATE_FORMAT_DMY:
        
        cout << dDay << '-' << dMonth << '-' << dYear;
        
        break;
        
        default:
        
        cout << dMonth << '-' << dDay << '-' << dYear;
    }
}

class extDateType: public dateType
{
    public:
    
    extDateType(int month, int day, int year) : dateType { month, day, year }
    {
        string longMonths[12] = { "January", "February", "March", "April", "May", "June",
                                  "July", "August", "September", "October", "November", "December" };
                              
        dMonthString = longMonths[dMonth - 1];      
    }
    
    void printFancyDate() const;

    string getMonthString() const;

    private:
    
    string dMonthString;

};

string extDateType::getMonthString() const
{
    return dMonthString;
}

void extDateType::printFancyDate() const
{
    cout << dMonthString << " " << dDay << ", " << dYear;
}

// Main

int main()
{
    int rc = 0;
    
    extDateType testDate(2,20,1968);
    
    cout << "After executing this statement: ";
    cout << "extDateType testDate(2,20,1968);\n\n";
    
    cout << "Here are the results:\n\n";
    cout << " testDate.printFancyDate(); prints --> ";
    
    testDate.printFancyDate(); // I do not like this method. Creating output
                               // within the class limits the robustness of
                               // the function. It should return a string.
    
    cout << endl << endl;
    
    cout << "I also modified (maintaining immutability) the original class to\n";
    cout << "support further formatting of standard dates. For example:\n\n";
    
    cout << "  dateType.printDate() = ";
    testDate.printDate();
    cout << endl;
    
    cout << "  dateType.printDate(DATE_FORMAT_YMD) = ";
    testDate.printDate(DATE_FORMAT_YMD);
    cout << endl;
    
    cout << "  dateType.printDate(DATE_FORMAT_DMY) = ";
    testDate.printDate(DATE_FORMAT_DMY);
    cout << endl;
    
    return 0;
}

