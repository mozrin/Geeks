#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

// NOTE!!!!
//
// If you want to modify something like the data filename to test error handling ... click the ForkThis
// button and then type in a new filename in your copy of the code and run. Thanks!!

using namespace std;

string extractLastName(string);
double calculateAverage(double, int);
char letterGrade(double);
void displayOutput(string, double, char);

void waitForKey();

int main()
{
    string nameStr; // variables to hold input fields
    int examOne; //
    int examTwo; //
    int finalExam; //
    string lastName; // variable to hold extracted last name value
    double overallAvg; // variable to hold calculated overall average
    char grade; // variable to hold grade character returned by function

    ifstream examScores; // input file stream object
    
    examScores.open("TestResults.txt");
    
    if (!examScores) // test for successful open of input file
    {
        cout << endl << "Input file not found." << endl << endl;
        waitForKey();
        return -1;
    }
    
    cout << endl;

    examScores >> nameStr; // priming read-input first field of first record
    
    while (!examScores.eof())
    {
        examScores >> examOne >> examTwo >> finalExam; // input rest of record fields
        
        lastName = extractLastName(nameStr);
        overallAvg = calculateAverage(examOne + examTwo + finalExam, 3);
        grade = letterGrade(overallAvg);
        
        displayOutput(lastName, overallAvg, grade); // call function to display output values

        examScores >> nameStr; // next read - input first field of next record
    }

    examScores.close();
    cout << endl;
    
    waitForKey();
    
    return 0;
}

void waitForKey()
{
    #ifdef _WIN32
    cout << "Press any key to continue ...";
    system("pause");
    #endif
    
    #ifdef __unix
    system("read -r -p \"Press <Enter> to continue...\" key");
    #endif
}

string extractLastName(string name)
{
    string last;
    int pos;
    
    pos = name.find(","); // position of comma
    last = name.substr(0, pos);// chars up to comma
    
    return last; // return last name
}

double calculateAverage(double sum, int cnt)
{
    double avg;
    avg = sum / cnt; // divide sum of text scores by number of scores (mixed-mode)
    
    return avg; // return calculated average
}

char letterGrade(double score)
{
    char grade;

    if (score >= 90.0)
    {
        grade = 'A';
    }
    
    else if (score >= 80.0)
    {
        grade = 'B';
    }
    
    else if (score >= 70.0)
    {
        grade = 'C';
    }
    
    else if (score >= 60.0)
    {
        grade = 'D';
    }
        
    else
    {
        grade = 'F';
    }

    return grade; // return assigned grade character
}

void displayOutput(string lName, double score, char letter)
{
    cout << fixed << setprecision(1); // fixed decimal number with decimal places set at 1
    cout << left << setw(20) << lName << right << setw(5) << score << " " << letter << endl;
}