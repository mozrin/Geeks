#include <bits/stdc++.h>

using namespace std;

// My Helper Functions & Definitions

#define PANDW(p,w) setprecision(p) << setw(w) << fixed

int WaitForUserToPressKey(int errorCode = 0, char waitKey = '\n', string = "Press <Enter> to end...");

string str_tolower(string s);
string str_toupper(string s);

// Assignment Constants

const double INCOME_LIMIT_MO = 37750;
const double INCOME_LIMIT_KS = 34500;
const double CREDIT_RATE = 0.0975;

// Assignment Functions

// main() Program Loop

int main()
{
    int rc = 0; // Pass any error codes to this variable before dropping out.
    
    char homeowner;
    
    double amountOfAnnualIncome, incomeLevel;
    
    string residentOfState;
    
    cout << "\nAre you a homeowner [Y/N]?  ";
    cin >> homeowner;
    cout << "\n";
    
    if (toupper(homeowner) == 'Y')
    {
        cout << "\nResident State [MO or KS]:  ";
        cin >> residentOfState;
        
        residentOfState = str_toupper(residentOfState);
        
        if (residentOfState == "MO" || residentOfState == "KS")
        {
            
            incomeLevel = (residentOfState == "MO" ? INCOME_LIMIT_MO : INCOME_LIMIT_KS);
            
            cout << "\n  Amount of annual income: $ ";
            cin >> amountOfAnnualIncome;
            
            if (amountOfAnnualIncome <= incomeLevel)
            {
                cout << "\n Allowed amount of credit: $ " << PANDW(0,4) << (amountOfAnnualIncome * CREDIT_RATE) << "\n";
            }
            
            else
            {
                cout << "\nApplicant ineligible.  Income too high.\n";
            }
        }
        
        else
        {
            cout << "\nApplicant ineligible.  Not a resident of Missouri or Kansas.\n";
        }
    }
    
    else
    {
        cout << "\nApplicant ineligible.  Not a homeowner.\n";
    }
    
    //----------------------------------------------------

    return WaitForUserToPressKey(); // Default is ENTER ...
}

string str_toupper(string s)
{
    transform( s.begin(),
               s.end(),
               s.begin(),
               
               [](unsigned char c){ return toupper(c); }
               
               );
    return s;
}

string str_tolower(string s)
{
    transform( s.begin(),
               s.end(),
               s.begin(),
               
               [](unsigned char c){ return tolower(c); }
               
               );
    return s;
}

int WaitForUserToPressKey(int errorCode, char waitKey, string message)
{
	char c;
	
	cout << "\n" << message;
	
	cin.clear();
	cin.ignore(5000, '\n');
	
	do
	{
	    c = getchar();
	    
	    if (c == waitKey) break;
	    
	} while (true);

	if (errorCode < 0 || errorCode > 0)
	{
	    cout << "\n\n" << "An error was passed to the exit routine. The error code is (" << errorCode << ")\n\n";
	    cout << "Note that an error code of -1 in the program will yield a 255 (invalid error code) upon exit.\n\n";
	}
	
	return errorCode;
}