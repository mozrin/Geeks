#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int WaitForUserToPressENTER(int errorCode = 0, string message = "Press <Enter> to end...");

int main()
{
	int integerOne = 0;
	int integerTwo = 0;
	int results;

	cout << endl << "Arithmetic Operations on Two Integers" << endl << endl;
	
	cout << "Enter the  first integer:  ";
	cin >> integerOne;
	cout << endl;
	cout << "Enter the second integer:  ";
	cin >> integerTwo;
	cout << endl;

	results = (integerOne + integerTwo);
	cout << integerOne << " + " << integerTwo << " = " << results << endl << endl;

	results = (integerOne - integerTwo);
	cout << integerOne << " - " << integerTwo << " = " << results << endl << endl;
	
	results = abs(integerOne - integerTwo);
	cout << integerOne << " - " << integerTwo << " = " << results << "       (absolute difference)" << endl << endl;
	
	results = (integerOne * integerTwo);
	cout << integerOne << " * " << integerTwo << " = " << results << endl << endl;
	
	results = (integerOne / integerTwo);
	cout << integerOne << " / " << integerTwo << " = " << results << endl << endl;
	
	results = (integerOne % integerTwo);
	cout << integerOne << " % " << integerTwo << " = " << results << endl << endl;	
		
	return WaitForUserToPressENTER();
}

int WaitForUserToPressENTER(int errorCode, string message) {

	cout << endl << endl << message;

	char getInput = ' ';

	cin.ignore();

	do {

		getInput = cin.get();

		if (getInput == '\n') { break; }

	} while (true);

	return errorCode;
}