#include <stdlib.h>
#include <iostream>
#include <conio.h>
#include <iomanip>
#include <string>
#include <algorithm>
#include <cctype>
#include <vector>

using namespace std;

// DEBUG constantz and associated macro

const bool		DEBUG = false;
const int		DEBUG_WIDTH = 55;
const string	DEBUG_NOTICE = "!!NOTICE!!\nYou are in DEBUG mode.\nTo exit, change DEBUG to false and recompile\n\n";

#define DEBUG_NOTICE() if(DEBUG) cout << setw(DEBUG_WIDTH) << "!!NOTICE!! ** YOU ARE IN DEBUG MODE **\n\n"
#define DEBUG(a) if(DEBUG) cout << setw(DEBUG_WIDTH) << "(var)=|" << #a << "| (value)=|" << (a) << "|" << endl

// Lower Level Custom Functions

string str_tolower(string unknownString);

// Make Life Easier Functions

int WaitForUserToPressENTER(int errorCode = 0, string message = "Press <Enter> to end...");

double GetPreviousBalance(string lastName);

// Beginning of main()

int main()
{
	DEBUG_NOTICE();

	string		firstName;
	string		middleName;
	string		lastName;

	int			age = 0;

	int			leftPadding = 25;
	int			loopForever = false; // If set to true, it will loop until someone types in quit for the first name.

	double		expenditures = 0;
	double		previousBalance = 0;
	double		currentBalance = 0;

	cout << fixed << setprecision(2);

	do
	{
		cout << endl;
		cout << setw(leftPadding) << "Type in the FIRST name:  ";
		getline(cin, firstName);
		DEBUG(firstName);

		if (str_tolower(firstName) == "quit") loopForever = false;

		else
		{
			cout << setw(leftPadding) << "MIDDLE name or initial:  ";
			getline(cin, middleName);
			DEBUG(middleName);

			cout << setw(leftPadding) << "Type in the  LAST name:  ";
			getline(cin, lastName);
			DEBUG(lastName);

			cout << setw(leftPadding) << "Enter the AGE in years:  ";
			cin >> age;

			cout << endl << endl;
			cout << left << setw(18) << "First name" << left << setw(15) << "Middle" << left << setw(20) << "Last name" << right << setw(3) << "Age" << endl;
			cout << left << setw(18) << "----------" << left << setw(15) << "------" << left << setw(20) << "---------" << right << setw(3) << "---" << endl;
			cout << left << setw(18) << firstName << left << setw(15) << middleName << left << setw(20) << lastName << right << setw(3) << age << endl;

			cout << endl << endl;
			cout << setw(leftPadding) << "Amount of expenditures:  ";
			cin >> expenditures;
			cout << endl << endl;

			previousBalance = GetPreviousBalance("Pretend I Am Passing A Key For Lookup");
			cout << setw(leftPadding-2) << "Previous Balance:  $";
			cout << right << setw(10) << setprecision(2) << previousBalance << endl;
			cout << setw(leftPadding-2) << "-";
			cout << right << setw(10) << setprecision(2) << expenditures << endl;
			cout << setw(leftPadding-2) << "";
			cout << "----------" << endl;
			cout << setw(leftPadding-2) << "Current Balance:  $";
			currentBalance = previousBalance - expenditures;
			cout << right << setw(10) << setprecision(2) << currentBalance << endl << endl;
			cout << setw(leftPadding-2) << "Formatted Output:  $";
			cout << right << setw(10) << setfill('#') << setprecision(2) << currentBalance << endl;			
		}

	} while (loopForever);

	return WaitForUserToPressENTER();
}

// END of main()

// Lower Level custom functions.

string str_tolower(string unknownString) {

	transform(unknownString.begin(),
		unknownString.end(),
		unknownString.begin(),

		[](unsigned char c) { return tolower(c); });

	return unknownString;
}

// Make Life Easier Functions

int WaitForUserToPressENTER(int errorCode, string message) {

	cout << endl << endl << message;

	char getInput = ' ';

	cin.ignore();

	do {

		getInput = cin.get();

		if (getInput == '\n') { break; }

	} while (true);

	return errorCode;
}

double GetPreviousBalance(string lastName)
{
	// Previous Balance is not going to be hard-coded. This is a stub to go get it later.

	double returnBalance = 10000;

	return returnBalance;
}