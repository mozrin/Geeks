#include <stdlib.h>
#include <iostream>
#include <conio.h>
#include <iomanip>
#include <string>
#include <algorithm>
#include <cctype>
#include <vector>

using namespace std;

// DEBUG constantz and associated macro

const bool		DEBUG = false;
const int		DEBUG_WIDTH = 55;
const string	DEBUG_NOTICE = "!!NOTICE!!\nYou are in DEBUG mode.\nTo exit, change DEBUG to false and recompile\n\n";

#define DEBUG_NOTICE() if(DEBUG) cout << setw(DEBUG_WIDTH) << "!!NOTICE!! ** YOU ARE IN DEBUG MODE **\n\n"
#define DEBUG(a) if(DEBUG) cout << setw(DEBUG_WIDTH) << "(var)=|" << #a << "| (value)=|" << (a) << "|" << endl

#define ADJUSTED(a) (a-1)

// Lower Level Custom Functions

string str_tolower(string unknownString);

// Make Life Easier Functions

int WaitForUserToPressENTER(int errorCode = 0, string message = "Press <Enter> to end...");

// Beginning of main()

int main()
{
	DEBUG_NOTICE();

	const int		PADDING = 25;

	const double	PLYWOOD_COST = 0.54;
	const double	STRAP_COST = 1.03;
	const double	LABOR_COST = 3.37;
	const double	MARKUP_COST = 0.35;

	const double	CUBIC_INCHES_TO_FEET = 1728;
	const double	SQUARE_INCHES_TO_FEET = 144;

	double lengthInInches, widthInInches, heightInInches, interiorVolume, estimatedCost, surfaceArea, edgesLinearFeet;

	cout << fixed << setprecision(2);

	cout << endl << "== Cost Estimate for Custom Crate ==" << endl;

	cout << setw(PADDING) << endl << "Enter length in inches:  ";
	cin >> lengthInInches;
	cout << setw(PADDING) << endl << "Enter  width in inches:  ";
	cin >> widthInInches;
	cout << setw(PADDING) << endl << "Enter height in inches:  ";
	cin >> heightInInches;
	
	interiorVolume = ((ADJUSTED(lengthInInches) * ADJUSTED(widthInInches) * ADJUSTED(heightInInches)) / CUBIC_INCHES_TO_FEET);
	surfaceArea = (((widthInInches * heightInInches) + (widthInInches * lengthInInches) + (lengthInInches * heightInInches)) * 2) / SQUARE_INCHES_TO_FEET;
	
	edgesLinearFeet = ((lengthInInches + widthInInches + heightInInches) * 4) / 12;

	estimatedCost = ((surfaceArea * PLYWOOD_COST) + (edgesLinearFeet * STRAP_COST) + LABOR_COST) * (1 + MARKUP_COST);

	cout << endl;
	cout << endl << "Interior volume of finished crate:" << right << setw(8) << setprecision(2) << interiorVolume << " cubic feet" << endl;
	cout << endl << "Estimated cost  of finished crate:" << right << setw(8) << setprecision(2) << estimatedCost << " dollars";
	
	return WaitForUserToPressENTER();
}

double InchesToFeet(double passed) { return (passed / 12); }




// END of main()

// Lower Level custom functions.

string str_tolower(string unknownString) {

	transform(unknownString.begin(),
		unknownString.end(),
		unknownString.begin(),

		[](unsigned char c) { return tolower(c); });

	return unknownString;
}

// Make Life Easier Functions

int WaitForUserToPressENTER(int errorCode, string message) {

	cout << endl << endl << message;

	char getInput = ' ';

	cin.ignore();

	do {

		getInput = cin.get();

		if (getInput == '\n') { break; }

	} while (true);

	return errorCode;
}