#include <bits/stdc++.h>

// NOTE!!!!
//
// If you want to modify something like the data filename to test error handling ... click the ForkThis
// button and then type in a new filename in your copy of the code and run. 
// 
// There are several example "BAD" files included that I used to test this snipet.
// 
// Thanks!!

using namespace std;

// My Helper Functions & Definitions

#define PANDW(p,w) setprecision(p) << setw(w) << fixed

const string INVENTORY_FILE = "inventory.txt";

int GetInteger(string q = "Enter an integer:  ");
int GetIntegerRange(string prompt, int lowNumber, int highNumber);
int WaitForUserToPressKey(int errorCode = 0, char waitKey = '\n', string = "Press <Enter> to end...");

bool isLeapYear(int year = -1);

string int_toBinary(int i, int b = 32);

string str_replace(string s, char a, char b);
string str_tolower(string s);
string str_toupper(string s);
string str_reverse(string s);
string str_repeat(string s, int n);

// Assignment Functions

void GenerateInventoryErrorMessage(int rc);

// main() Program Loop

int main()
{
    int rc = 0; // Pass any error codes to this variable before dropping out.
    
    int quantity = 0, counter = 0;
    
    bool fileOkay = true;
    
    double cost = 0, inventoryTotalValue = 0, itemTotalValue;
    
    string itemCode, description;
    
    ifstream employeeFile(INVENTORY_FILE);
    
    if (employeeFile.fail())
    {
        rc = -1;
    }
    
    else
    {
        // Inventory Print Header
        
        cout << str_repeat(" ", 17) << "Inventory Items\n";
        cout << "Item ID     Cost   Qty   Total Value   Description\n";
        cout << "-------  -------   ---   -----------   -----------\n";
        
        // Loop Through The File and Print Data
        
        do
        {
            // This code assumes you are not entering bad data into the file.
            
            if (employeeFile.eof()) { break; } // Last record .. time to exit loop.
            
            employeeFile >> itemCode >> cost >> quantity >> description;
            
            if (cost <= 0 || quantity < 0 || itemCode == "") // Data Is Corrupt
            {
                rc = -2;
                break;
            }
            
            counter++;
            
            cout << " " << itemCode;
            cout << "   " << PANDW(2,7) << cost;
            cout << "   " << PANDW(0,3) << quantity;
            
            itemTotalValue = cost * quantity;
            
            cout << "   " << PANDW(2,11) << itemTotalValue;
            
            inventoryTotalValue += itemTotalValue;
            
            cout << "   " << description << "\n";
            
        } while (true);
        
        if (!rc) 
        {
            cout << "\n   " << PANDW(0,3) << counter << " items";
            cout << str_repeat(" ", 13) << "$" << PANDW(2,10) << inventoryTotalValue << "\n\n";
        }    
        
        employeeFile.close();
    }
    
    if (rc) { GenerateInventoryErrorMessage(rc); }
    
    //----------------------------------------------------

    return WaitForUserToPressKey(rc); // Default is ENTER ...
}

void GenerateInventoryErrorMessage(int rc)
{
    switch (rc)
    {
        case -1:
        
        cout << "The file you are trying to open does not exist. (" << rc << ")\n";
        
        break;
    
        case -2:
    
        cout << "The file is corrupt. (" << rc << ")\n";
        
        break;
    }
    
    return;
}

int GetInteger(string q)
{
    int returnCode;
    
    do
    {
        cout << q;
        
        if (cin >> returnCode) break;
        
        cin.clear();
        cin.ignore();
        
    } while (true);
    
    return returnCode;
}

int GetIntegerRange(string prompt, int lowNumber, int highNumber)
{
    int inputNumber;
    
    do
    {
        inputNumber = GetInteger(prompt);
        
        cout << "Broken Do Not Use";
        
        if (inputNumber < lowNumber || inputNumber > highNumber )
        {
            cout << "**** INVALID Number: Must be >= " << lowNumber;
            cout << " and <= " << highNumber << "!\n";
        }
        
        else
        { 
            cout << endl;
            break;
        }
        
    } while (true);
}

string str_repeat(string s, int n)
{
    string rc = "";
    
    for (int i=0; i<n; i++)
    {
        rc += s;
    }
    
    return rc;
}

string str_reverse(string s)
{
    string rc = "";
    
    for (int i=s.length(); i>=0; i--)
    {
        rc += s[i];
    }
    
    return rc;
}

string str_replace(string s, char a, char b)
{
    replace( s.begin(), s.end(), a, b);
    
    return s;
}

string str_toupper(string s)
{
    transform( s.begin(),
               s.end(),
               s.begin(),
               
               [](unsigned char c){ return toupper(c); }
               
               );
    return s;
}

string str_tolower(string s)
{
    transform( s.begin(),
               s.end(),
               s.begin(),
               
               [](unsigned char c){ return tolower(c); }
               
               );
    return s;
}

string int_toBinary(int i, int b)
{
    string r = "";
    
    if (i>0)
    {
        while (i>0)
        {
            r = ((i % 2) == 0 ? "0" : "1" ) + r;
            i /= 2;
        }
    }
    
    r = string(b, '0') + r;
    r = r.substr(r.length() - b);

    return r;
}

bool isLeapYear(int year)
{
    bool returnCode = false;
    
    if (year == -1)
    {
        time_t t = time(NULL);
        tm* timePtr = localtime(&t);
        
        year = timePtr->tm_year;
    }
    
    returnCode = (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0));
    
    return returnCode;
}

int WaitForUserToPressKey(int errorCode, char waitKey, string message)
{
	char c;
	
	cout << "\n" << message;
	
	// while ((getchar()) != '\n'); // Clear Buffer (find something more elegant)
	
	do
	{
	    c = getchar();
	    
	    if (c == waitKey) break;
	    
	} while (true);

	if (errorCode < 0 || errorCode > 0)
	{
	    cout << "\n\n" << "An error was passed to the exit routine. The error code is (" << errorCode << ")\n\n";
	    cout << "Note that an error code of -1 in the program will yield a 255 (invalid error code) upon exit.\n\n";
	}
	
	return errorCode;
}




