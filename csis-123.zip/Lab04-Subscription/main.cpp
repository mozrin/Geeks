#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

#define PANDW(p,w) setprecision(p) << setw(w) << fixed

int main()
{
	const double SUBSCRIPTION_COST = 27.95;

	string firstName;
	string middleName;
	string lastName;

	int quantity;

	double totalAmount;

	cout << fixed;

	cout << endl << PANDW(2,15) << "First name:  ";
	cin >> firstName;

	cout << PANDW(2,15) << "Middle:  ";
	cin >> middleName;

	cout << PANDW(2,15) << "Last name:  ";
	cin >> lastName;

	cout << PANDW(2,15) << "Quantity:  " ;
	cin >> quantity;

	cout << endl << " === Subscription Order ===" << endl;

	totalAmount = quantity * SUBSCRIPTION_COST;

	cout << endl << " " << firstName << " " << (middleName == "" ? "" : middleName + " ") << lastName << endl;
	cout << endl << " " << left << quantity << "    @  $" << SUBSCRIPTION_COST << "    $" << totalAmount << endl;

	cout << endl;
	
	// system("pause");
	system("read -r -p \"Press <Enter> to continue...\" key"); // Linux version of pause.
	
	return 0;
}



