#include <iostream>
#include <string>

using namespace std;

int main() {
    
	string userName;

	cout << endl << "Enter your name:  ";
	getline(cin, userName);

	cout << endl << "Hello " << userName << " !" << endl;

	cout << endl;
	 
	// system("pause");
	system("read -r -p \"Press <Enter> to continue...\" key"); // Linux version of pause.

	return 0;
}

