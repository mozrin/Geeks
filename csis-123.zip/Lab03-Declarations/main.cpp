#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

#define PANDW(p,w) setprecision(p) << setw(w) << fixed

int main()
{
	const double PI = 3.1415926;
	const float  E = 2.71828f;

	double radius = 6.85;
	double height = 17.4;
	double diameter, circumference, area;
	double sphereVolume, sphereSurface;
	double cylinderVolume;

	diameter = radius * 2.0;
	circumference = PI * diameter;
	area = PI * radius * radius;

	sphereVolume = (4.0 / 3.0) * PI * radius * radius * radius;
	sphereSurface = 4.0 * PI * radius * radius;

	cylinderVolume = PI * radius * radius * height;

	cout << fixed << setprecision(3) << endl;
	cout << "Diameter of circle      " << PANDW(1,7) << diameter << endl;
	cout << "Circumference of circle " << PANDW(4,7) << circumference << endl;
	cout << "Area of circle          " << PANDW(3,7) << area << endl;
	cout << endl;
	cout << "Volume of sphere        " << PANDW(2,7) << sphereVolume << endl;
	cout << "Surface of sphere       " << PANDW(3,7) << sphereSurface << endl;
	cout << endl;
	cout << "Cylinder volume         " << PANDW(2,7) << cylinderVolume << endl;

	cout << endl;

	// system("pause");
	system("read -r -p \"Press <Enter> to continue...\" key"); // Linux version of pause.

	return 0;
}



