#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

#define PANDW(p,w) setprecision(p) << setw(w) << fixed

int main()
{
	const double REGULAR_COST = 85.00;
	const double LIFETIME_COST = 495.00;
	const double DISCOUNT = 0.32;

	int membershipCount = 0;

	char membershipType = ' ';

	double membershipCostEach = 0;
	double membershipCostTotal = 0;
	double membershipDiscountMultiplier = 0;

	string familyName;

	cout << fixed << setprecision(2);

	cout << endl << " Enter Family name:  ";
	getline(cin, familyName);
	cout << endl;

	do {

		cout << " Reg or Life - R/L?  ";
		cin >> membershipType;

		membershipType = toupper(membershipType);

		cout << endl;

		if (membershipType == 'R' || membershipType == 'L') {
			
			membershipCostEach = (membershipType == 'R' ? REGULAR_COST : LIFETIME_COST);

			break;
		}		

	} while (true);

	cout << "  Membership count:  ";
	cin >> membershipCount;

	membershipDiscountMultiplier = (membershipCount >= 5 ? (1 - DISCOUNT) : 1);

	membershipCostEach = membershipCostEach * membershipDiscountMultiplier;

	membershipCostTotal = membershipCostEach * membershipCount;

	cout << endl << endl;
	cout << " " << membershipCount << " memberships @ $ " << membershipCostEach << "  =  $ " << membershipCostTotal;
	
	cout << endl << endl;

	// system("pause");
	system("read -r -p \"Press <Enter> to continue...\" key"); // Linux version of pause.

	return 0;
}

